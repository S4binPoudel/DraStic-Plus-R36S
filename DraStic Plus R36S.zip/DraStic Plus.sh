#!/bin/bash
#
# DraStic Plus - EmulationStation "Ports" launcher for ArkOS / dArkOS (R36S)
#
# Runs the DraStic 2.5.2.2 that is already installed in /opt/drastic, with the
# DraStic+ add-on library (mic loudness/pitch, right stick sensitivity,
# screen-over-screen overlay, performance toggles). /opt/drastic and the saves
# of the normal EmulationStation DraStic are never modified: this port keeps
# its own config and saves in the "drastic-plus" folder next to this script,
# and only ever COPIES old saves in.
#
# In game: hold SELECT and press Y for the DraStic+ menu.
#

PORTS_DIR="$(cd "$(dirname "$(readlink -f "$0")")" && pwd)"
DP="$PORTS_DIR/drastic-plus"
DRASTIC_HOME="${DRASTIC_HOME:-/opt/drastic}"
DRASTIC_BIN="$DRASTIC_HOME/drastic"
EXPECTED_MD5="17550db727f3b59d36b57746ad1944be"   # DraStic 2.5.2.2 aarch64 (ArkOS/dArkOS)
PLUS_CFG="$DP/drastic_plus.cfg"
STATE="$DP/launcher.cfg"
LOGDIR="$DP/logs"
TTY=/dev/tty1
TITLE="DraStic Plus"
# NDS folders of the EmulationStation DraStic (first one = main SD card)
read -r -a NDS_DIRS <<< "${DP_NDS_DIRS:-/roms/nds /roms2/nds}"
GPTOKEYB=/opt/inttools/gptokeyb

# --------------------------------------------------------------------------
# console UI (dialog + gptokeyb, like the other ArkOS tools)
# --------------------------------------------------------------------------

log() { printf '%s %s\n' "$(date '+%F %T')" "$*" >> "$LOGDIR/launcher.log" 2>/dev/null; }

set_font() {
    for f in /usr/share/consolefonts/Lat7-Terminus16.psf.gz /usr/share/consolefonts/Lat7-TerminusBold16.psf.gz; do
        if [ -f "$f" ]; then sudo setfont -C "$TTY" "$f" 2>/dev/null || sudo setfont "$f" 2>/dev/null; break; fi
    done
}

ui_start() {
    sudo chmod 666 "$TTY" /dev/uinput 2>/dev/null
    export TERM=linux
    printf "\033c" > "$TTY"
    set_font
    keys_start
}

keys_start() {
    if [ -x "$GPTOKEYB" ] && ! pgrep -f "gptokeyb.*dp-keys.gptk" >/dev/null; then
        export SDL_GAMECONTROLLERCONFIG_FILE="/opt/inttools/gamecontrollerdb.txt"
        "$GPTOKEYB" -c "$DP/dp-keys.gptk" >/dev/null 2>&1 &
        sleep 0.3
        log "gptokeyb started (pid $!)"
    fi
}

keys_stop() {
    pkill -f "gptokeyb.*dp-keys.gptk" 2>/dev/null
    sleep 0.2
}

# DraStic quits with exit() and never hands the console back (no SDL_Quit),
# which can leave tty1 hidden or with the keyboard muted. Make it a normal
# text console again so the game list can be shown and used.
restore_console() {
    if command -v python3 >/dev/null 2>&1; then
        sudo python3 - "$TTY" <<'PY' 2>/dev/null
import fcntl, os, sys
fd = os.open(sys.argv[1], os.O_RDWR | os.O_NOCTTY)
for req, arg in ((0x4B3A, 0x00), (0x4B45, 0x03)):  # KDSETMODE KD_TEXT, KDSKBMODE K_UNICODE
    try:
        fcntl.ioctl(fd, req, arg)
    except OSError:
        pass
os.close(fd)
PY
    elif command -v kbd_mode >/dev/null 2>&1; then
        sudo kbd_mode -u -C "$TTY" 2>/dev/null
    fi
    # switching virtual terminals makes the kernel repaint the text console
    if command -v chvt >/dev/null 2>&1 && [ "$(sudo fgconsole 2>/dev/null)" = 1 ]; then
        sudo chvt 2 2>/dev/null
        sleep 0.2
        sudo chvt 1 2>/dev/null
    fi
    sudo chmod 666 "$TTY" /dev/uinput 2>/dev/null
    stty sane < "$TTY" 2>/dev/null
    printf "\033c" > "$TTY"
    set_font
    log "console restored"
}

ui_end() {
    keys_stop
    printf "\033c" > "$TTY"
}

# dialog draws on the tty, reads the tty, and hands its answer back on fd 3
d() {
    local out
    out=$(dialog --backtitle "$TITLE  -  DraStic 2.5.2.2 with extras" --output-fd 3 "$@" 3>&1 1>"$TTY" 2>/dev/null <"$TTY")
    local rc=$?
    printf '%s' "$out"
    return $rc
}
msg()  { d --title "$TITLE" --msgbox "$1" "${2:-12}" "${3:-64}"; }
info() { d --title "$TITLE" --infobox "$1" "${2:-6}" "${3:-56}"; }
ask()  { d --title "$TITLE" --yes-label "${3:-Yes}" --no-label "${4:-No}" --yesno "$1" "${2:-10}" 64; }

# --------------------------------------------------------------------------
# small key = value stores (launcher state + DraStic+ settings)
# --------------------------------------------------------------------------

kv_get() { # file key default
    local v
    v=$(sed -n "s/^$2[[:space:]]*=[[:space:]]*//p" "$1" 2>/dev/null | tail -n 1)
    printf '%s' "${v:-$3}"
}

kv_set() { # file key value
    if grep -q "^$2[[:space:]]*=" "$1" 2>/dev/null; then
        sed -i "s|^$2[[:space:]]*=.*|$2 = $3|" "$1"
    else
        printf '%s = %s\n' "$2" "$3" >> "$1"
    fi
}

state_get() { kv_get "$STATE" "$1" "$2"; }
state_set() { kv_set "$STATE" "$1" "$2"; }

# --------------------------------------------------------------------------
# first run / data folder
# --------------------------------------------------------------------------

setup_data_dir() {
    mkdir -p "$DP" "$LOGDIR" || return 1
    for d in config backup savestates cheats slot2 microphone profiles input_record unzip_cache system; do
        mkdir -p "$DP/$d"
    done
    # Controls and options start as a copy of the normal DraStic config.
    if [ ! -f "$DP/config/drastic.cfg" ]; then
        if [ -f "$DRASTIC_HOME/config/drastic.cfg" ]; then
            cp -p "$DRASTIC_HOME/config/drastic.cfg" "$DP/config/drastic.cfg"
        fi
    fi
    # Read-only DraStic data files are shared by link (never written).
    for f in system/drastic_bios_arm7.bin system/drastic_bios_arm9.bin system/nds_bios_arm7.bin \
             system/nds_bios_arm9.bin system/nds_firmware.bin usrcheat.dat game_database.xml \
             drastic_logo_0.raw drastic_logo_1.raw; do
        if [ -e "$DRASTIC_HOME/$f" ] && [ ! -e "$DP/$f" ]; then
            ln -s "$DRASTIC_HOME/$f" "$DP/$f" 2>/dev/null || cp -p "$DRASTIC_HOME/$f" "$DP/$f"
        fi
    done
    # Fake-mic sound files and cheats: copy what is missing.
    copy_missing "$DRASTIC_HOME/microphone" "$DP/microphone"
    for c in "$DRASTIC_HOME/cheats" "${NDS_DIRS[@]/%//cheats}"; do
        copy_missing "$(readlink -f "$c" 2>/dev/null)" "$DP/cheats"
    done
    # Slot-2 GBA ROMs are linked (read-only), anything else is copied.
    for s in "$DRASTIC_HOME/slot2" "${NDS_DIRS[@]/%//slot2}"; do
        s=$(readlink -f "$s" 2>/dev/null)
        [ -n "$s" ] && [ -d "$s" ] || continue
        for f in "$s"/*; do
            [ -f "$f" ] || continue
            local b; b=$(basename "$f")
            [ -e "$DP/slot2/$b" ] && continue
            case "${b,,}" in
                *.gba|*.zip|*.7z) ln -s "$f" "$DP/slot2/$b" 2>/dev/null ;;
                *) cp -p "$f" "$DP/slot2/$b" ;;
            esac
        done
    done
    [ -f "$STATE" ] || printf 'auto_import = 1\nafter_game = menu\n' > "$STATE"
    return 0
}

copy_missing() { # src_dir dst_dir
    [ -n "$1" ] && [ -d "$1" ] || return 0
    local f
    for f in "$1"/*; do
        [ -f "$f" ] || continue
        [ -e "$2/$(basename "$f")" ] || cp -p "$f" "$2/"
    done
}

# --------------------------------------------------------------------------
# old (EmulationStation DraStic) save locations
# --------------------------------------------------------------------------

old_dirs() { # backup|savestates -> one directory per line
    local kind="$1" mine seen="" d r
    mine=$(readlink -f "$DP/$kind")
    for d in "$DRASTIC_HOME/$kind" "${NDS_DIRS[@]/%//$kind}"; do
        r=$(readlink -f "$d" 2>/dev/null) || continue
        [ -d "$r" ] || continue
        [ "$r" = "$mine" ] && continue
        case "|$seen|" in *"|$r|"*) continue ;; esac
        seen="$seen|$r"
        printf '%s\n' "$r"
    done
}

rom_name() { local b; b=$(basename "$1"); printf '%s' "${b%.*}"; }

find_old_save() { # name -> path of the old .dsv (or raw .sav)
    local d
    while IFS= read -r d; do
        [ -f "$d/$1.dsv" ] && { printf '%s' "$d/$1.dsv"; return 0; }
        [ -f "$d/$1.sav" ] && { printf '%s' "$d/$1.sav"; return 0; }
    done < <(old_dirs backup)
    return 1
}

old_states() { # name -> old savestate files, one per line
    local d f b
    while IFS= read -r d; do
        for f in "$d"/*.dss; do
            [ -f "$f" ] || continue
            b=$(basename "$f")
            case "$b" in "$1"_*.dss|"$1".dss) printf '%s\n' "$f" ;; esac
        done
    done < <(old_dirs savestates)
}

# Copy the old save/states of one game if this port has none yet.
auto_import() { # rom -> prints a summary line if anything was copied
    local name new old n=0 f
    name=$(rom_name "$1")
    new="$DP/backup/$name.dsv"
    if [ ! -e "$new" ] && old=$(find_old_save "$name"); then
        cp -p "$old" "$new" && echo "Game save copied from $(dirname "$old")"
    fi
    while IFS= read -r f; do
        [ -e "$DP/savestates/$(basename "$f")" ] && continue
        cp -p "$f" "$DP/savestates/" && n=$((n + 1))
    done < <(old_states "$name")
    [ "$n" -gt 0 ] && echo "$n savestate(s) copied"
}

# Before opening DraStic's own file browser we do not know the game, so copy
# every old game save that this port does not have yet (saves are small).
import_all_missing_saves() {
    local d f n=0
    while IFS= read -r d; do
        for f in "$d"/*.dsv; do
            [ -f "$f" ] || continue
            [ -e "$DP/backup/$(basename "$f")" ] && continue
            cp -p "$f" "$DP/backup/" && n=$((n + 1))
        done
    done < <(old_dirs backup)
    [ "$n" -gt 0 ] && echo "$n game save(s) copied from the EmulationStation DraStic"
}

# --------------------------------------------------------------------------
# ROM picker
# --------------------------------------------------------------------------

ROMS=()
scan_roms() {
    ROMS=()
    local r
    for r in "${NDS_DIRS[@]}"; do
        [ -d "$r" ] || continue
        while IFS= read -r f; do ROMS+=("$f"); done < <(
            find "$r" -maxdepth 2 -type f \( -iname '*.nds' -o -iname '*.zip' -o -iname '*.7z' -o -iname '*.rar' \) \
                -not -path '*/backup/*' -not -path '*/savestates/*' -not -path '*/slot2/*' 2>/dev/null | sort -f)
    done
}

pick_rom() { # title [path to highlight] -> prints chosen path
    scan_roms
    if [ ${#ROMS[@]} -eq 0 ]; then
        msg "No NDS games found in ${NDS_DIRS[*]}."
        return 1
    fi
    local items=() i=0 f label two=0 def=1
    [ -d "${NDS_DIRS[0]}" ] && [ -d "${NDS_DIRS[1]}" ] && two=1
    for f in "${ROMS[@]}"; do
        i=$((i + 1))
        [ -n "$2" ] && [ "$f" = "$2" ] && def=$i
        label="${f#"${NDS_DIRS[0]}"/}"
        if [ -n "${NDS_DIRS[1]}" ] && [ "$label" = "$f" ]; then
            label="${f#"${NDS_DIRS[1]}"/}"
            [ "$two" = 1 ] && label="[SD2] $label"
        fi
        [ -f "$DP/backup/$(rom_name "$f").dsv" ] && label="$label  *"
        items+=("$i" "${label:0:70}")
    done
    local c
    c=$(d --title "$1" --cancel-label "Back" --default-item "$def" --menu \
        "* = has a DraStic Plus save.  L1/R1: page up/down.  In game SELECT+START quits back here." \
        28 78 20 "${items[@]}") || return 1
    printf '%s' "${ROMS[$((c - 1))]}"
}

# --------------------------------------------------------------------------
# save manager
# --------------------------------------------------------------------------

describe() { # file -> "date, size"
    printf '%s, %sK' "$(date -r "$1" '+%Y-%m-%d %H:%M' 2>/dev/null)" "$(( ($(stat -c %s "$1" 2>/dev/null || echo 0) + 1023) / 1024 ))"
}

backup_current() { # keep the current Plus save before replacing it
    local cur="$DP/backup/$1.dsv"
    [ -f "$cur" ] && cp -p "$cur" "$DP/backup/$1.dsv.bak-$(date +%Y%m%d-%H%M%S)"
}

pick_save_file() { # name
    local name="$1" files=() items=() i=0 f
    while IFS= read -r f; do files+=("$f"); done < <(
        for r in "${NDS_DIRS[@]}" "$DRASTIC_HOME"; do
            [ -d "$r" ] && find -L "$r" -maxdepth 3 -type f \( -iname '*.dsv' -o -iname '*.sav' -o -iname '*.dsv.bak-*' \) 2>/dev/null
        done | while IFS= read -r p; do readlink -f "$p"; done | sort -u | grep -vF "$(readlink -f "$DP")/")
    if [ ${#files[@]} -eq 0 ]; then
        msg "No .dsv or .sav files found in ${NDS_DIRS[*]} or $DRASTIC_HOME."
        return 1
    fi
    for f in "${files[@]}"; do
        i=$((i + 1))
        items+=("$i" "$(basename "$f" | cut -c1-40)  ($(describe "$f"))  $(dirname "$f" | cut -c1-24)")
    done
    local c
    c=$(d --title "Pick a save for: ${name:0:50}" --menu "The file you pick is COPIED into DraStic Plus; the original stays untouched." 28 78 20 "${items[@]}") || return 1
    f="${files[$((c - 1))]}"
    ask "Use this save for\n  $name\n\n$f\n($(describe "$f"))\n\nThe current DraStic Plus save is kept as a .bak copy." 14 || return 1
    backup_current "$name"
    cp -p "$f" "$DP/backup/$name.dsv" && msg "Done. DraStic Plus will now load:\n\n$f" 10
}

restore_bak() { # name
    local name="$1" baks=() items=() i=0 f
    for f in "$DP/backup/"*.bak-*; do
        [ -f "$f" ] || continue
        case "$(basename "$f")" in "$name.dsv.bak-"*) baks+=("$f") ;; esac
    done
    if [ ${#baks[@]} -eq 0 ]; then msg "No earlier DraStic Plus save copies for this game."; return 1; fi
    for f in "${baks[@]}"; do i=$((i + 1)); items+=("$i" "$(basename "$f" | sed 's/.*\.bak-//')  ($(describe "$f"))"); done
    local c
    c=$(d --title "Restore earlier save" --menu "Pick the copy to restore:" 20 70 12 "${items[@]}") || return 1
    backup_current "$name"
    cp -p "${baks[$((c - 1))]}" "$DP/backup/$name.dsv" && msg "Restored."
}

save_manager() {
    local rom name c old states
    rom=$(pick_rom "Save manager: choose a game") || return
    name=$(rom_name "$rom")
    while true; do
        old=$(find_old_save "$name")
        states=$(old_states "$name" | wc -l)
        local cur="none yet"
        [ -f "$DP/backup/$name.dsv" ] && cur=$(describe "$DP/backup/$name.dsv")
        c=$(d --title "${name:0:60}" --menu "DraStic Plus save: $cur\nEmulationStation DraStic save: ${old:+$(describe "$old")}${old:-none}" 18 72 7 \
            1 "Play this game" \
            2 "Pick a save file manually" \
            3 "Copy save from EmulationStation DraStic" \
            4 "Copy savestates from EmulationStation DraStic ($states)" \
            5 "Restore an earlier DraStic Plus save" \
            6 "Show save folders" \
            7 "Back") || return
        case "$c" in
            1) launch_game "$rom"; return ;;
            2) pick_save_file "$name" ;;
            3) if [ -z "$old" ]; then msg "The EmulationStation DraStic has no save for this game."
               elif ask "Replace the DraStic Plus save with the one from EmulationStation DraStic?\n\n$old\n\nThe current Plus save is kept as a .bak copy." 13; then
                   backup_current "$name"; cp -p "$old" "$DP/backup/$name.dsv" && msg "Copied."
               fi ;;
            4) local n=0 f
               while IFS= read -r f; do
                   [ -e "$DP/savestates/$(basename "$f")" ] && ! ask "Overwrite DraStic Plus savestate $(basename "$f")?" 8 && continue
                   cp -p "$f" "$DP/savestates/" && n=$((n + 1))
               done < <(old_states "$name")
               msg "$n savestate(s) copied." 6 40 ;;
            5) restore_bak "$name" ;;
            6) msg "DraStic Plus (this port) saves to:\n  $DP/backup\n  $DP/savestates\n\nEmulationStation DraStic saves (read only here):\n$(old_dirs backup | sed 's/^/  /')\n$(old_dirs savestates | sed 's/^/  /')" 16 72 ;;
            *) return ;;
        esac
    done
}

# --------------------------------------------------------------------------
# options
# --------------------------------------------------------------------------

onoff() { [ "$1" = 1 ] && echo On || echo Off; }

options_menu() {
    local c
    while true; do
        local ai preset after
        ai=$(state_get auto_import 1)
        after=$(state_get after_game menu)
        preset=$(kv_get "$PLUS_CFG" perf_speed_preset 0)
        c=$(d --title "Options" --menu "In game: SELECT+Y opens the DraStic+ menu (mic, stylus, overlay, hacks)." 18 74 7 \
            1 "Copy old saves automatically on first play: $(onoff "$ai")" \
            2 "Speed preset (performance hack): $(onoff "$preset")" \
            3 "After quitting a game: $( [ "$after" = es ] && echo 'back to EmulationStation' || echo 'back to this menu')" \
            4 "Re-copy controls/config from EmulationStation DraStic" \
            5 "Reset DraStic+ extra settings to stock" \
            6 "Back") || return
        case "$c" in
            1) state_set auto_import $((1 - ai)) ;;
            2) [ -f "$PLUS_CFG" ] || : > "$PLUS_CFG"; kv_set "$PLUS_CFG" perf_speed_preset $((1 - preset)) ;;
            3) if [ "$after" = es ]; then state_set after_game menu; else state_set after_game es; fi ;;
            4) if ask "Replace DraStic Plus controls and DraStic options with a fresh copy of\n$DRASTIC_HOME/config/drastic.cfg ?" 9; then
                   cp -p "$DP/config/drastic.cfg" "$DP/config/drastic.cfg.bak-$(date +%Y%m%d-%H%M%S)" 2>/dev/null
                   cp -p "$DRASTIC_HOME/config/drastic.cfg" "$DP/config/drastic.cfg" && rm -f "$DP/config/.speed_preset_backup" && msg "Copied."
               fi ;;
            5) ask "Reset mic, stylus, overlay and performance hacks to stock?" 8 && rm -f "$PLUS_CFG" && msg "Reset." 6 30 ;;
            *) return ;;
        esac
    done
}

# Speed preset: write DraStic's own speed options, remembering the user's
# values so turning it off restores them exactly.
apply_speed_preset() {
    local dcfg="$DP/config/drastic.cfg" bak="$DP/config/.speed_preset_backup"
    local keys="frameskip_type frameskip_value threaded_3d disable_edge_marking hires_3d interframe_blend"
    [ -f "$dcfg" ] || return
    if [ "$(kv_get "$PLUS_CFG" perf_speed_preset 0)" = 1 ]; then
        if [ ! -f "$bak" ]; then
            for k in $keys; do printf '%s = %s\n' "$k" "$(kv_get "$dcfg" "$k" "")"; done > "$bak"
        fi
        kv_set "$dcfg" frameskip_type 2
        kv_set "$dcfg" frameskip_value 3
        kv_set "$dcfg" threaded_3d 1
        kv_set "$dcfg" disable_edge_marking 1
        kv_set "$dcfg" hires_3d 0
        kv_set "$dcfg" interframe_blend 0
    elif [ -f "$bak" ]; then
        while IFS= read -r line; do
            k="${line%% =*}"; v="${line#*= }"
            [ -n "$k" ] && [ -n "$v" ] && kv_set "$dcfg" "$k" "$v"
        done < "$bak"
        rm -f "$bak"
    fi
}

# --------------------------------------------------------------------------
# launching DraStic
# --------------------------------------------------------------------------

check_drastic() {
    if [ ! -x "$DRASTIC_BIN" ]; then
        msg "DraStic was not found at $DRASTIC_BIN.\n\nDraStic Plus uses the DraStic that comes with ArkOS/dArkOS; please make sure NDS games work from EmulationStation first." 12
        return 1
    fi
    local sum
    sum=$(md5sum "$DRASTIC_BIN" 2>/dev/null | cut -d' ' -f1)
    EXTRAS_ACTIVE=1
    if [ -n "$sum" ] && [ "$sum" != "$EXPECTED_MD5" ]; then
        EXTRAS_ACTIVE=0
        if [ "$(state_get warned_md5 '')" != "$sum" ]; then
            state_set warned_md5 "$sum"
            msg "Your $DRASTIC_BIN is not the DraStic 2.5.2.2 build DraStic Plus was made for.\n\nGames will still run normally, but the extra features switch themselves off." 12
        fi
    fi
    return 0
}

preload_path() {
    # LD_PRELOAD cannot contain spaces
    case "$DP" in
        *" "*) cp -f "$DP/libdrastic_plus.so" /tmp/libdrastic_plus.so; printf '%s' /tmp/libdrastic_plus.so ;;
        *) printf '%s' "$DP/libdrastic_plus.so" ;;
    esac
}

run_drastic() { # [rom]
    local killer="" rc
    keys_stop
    printf "\033c" > "$TTY"
    apply_speed_preset
    # SELECT+START is handled inside DraStic+ (clean quit through DraStic).
    # Only if the extras are off, fall back to the system's force-quit helper.
    if [ "${EXTRAS_ACTIVE:-1}" = 0 ]; then
        if systemctl list-unit-files 2>/dev/null | grep -q '^killer_daemon.service'; then
            echo "VAR=drastic" > /home/ark/.config/KILLIT
            sudo systemctl restart killer_daemon.service && killer=daemon
        elif [ -f /usr/local/bin/drastickeydemon.py ]; then
            sudo python3 /usr/local/bin/drastickeydemon.py >/dev/null 2>&1 &
            killer=keydemon
        fi
    fi
    log "start: $DRASTIC_BIN $*"
    (
        cd "$DP" || exit 1
        export LD_PRELOAD
        LD_PRELOAD="$(preload_path)"
        export DRASTIC_PLUS_CFG="$PLUS_CFG"
        export DRASTIC_PLUS_LOG="$LOGDIR/drastic_plus.log"
        "$DRASTIC_BIN" "$@" > "$LOGDIR/drastic.log" 2>&1
    )
    rc=$?
    log "drastic exited with code $rc"
    case "$killer" in
        daemon) sudo systemctl stop killer_daemon.service; sudo systemctl restart ogage & ;;
        keydemon) sudo pkill -f drastickeydemon.py ;;
    esac
    restore_console
}

launch_game() { # rom
    local rom="$1" note=""
    check_drastic || return
    state_set last_rom "$rom"
    if [ "$(state_get auto_import 1)" = 1 ]; then
        note=$(auto_import "$rom")
        [ -n "$note" ] && info "$note" 6 60 && sleep 2
    fi
    run_drastic "$rom"
    if [ "$(state_get after_game menu)" = es ]; then
        ui_end
        exit 0
    fi
    keys_start
}

# Game list -> play -> back to the same list (last game highlighted).
play_loop() { # [first rom to start]
    local rom="$1"
    while true; do
        if [ -n "$rom" ]; then
            launch_game "$rom"
        fi
        rom=$(pick_rom "Choose a game" "$(state_get last_rom "")") || return
    done
}

launch_browser() {
    check_drastic || return
    if [ "$(state_get auto_import 1)" = 1 ]; then
        local note; note=$(import_all_missing_saves)
        [ -n "$note" ] && info "$note" 6 60 && sleep 2
    fi
    run_drastic
    keys_start
}

# --------------------------------------------------------------------------
# main menu
# --------------------------------------------------------------------------

main_menu() {
    local c last
    while true; do
        last=$(state_get last_rom "")
        [ -n "$last" ] && [ ! -f "$last" ] && last=""
        c=$(d --title "$TITLE" --cancel-label "Exit" --menu \
            "DraStic 2.5.2.2 + extras. Saves are separate from the EmulationStation DraStic.\nIn game: SELECT+Y = DraStic+ menu, SELECT+X = overlay, SELECT+START = quit." 18 74 7 \
            1 "Play a game" \
            2 "Continue: ${last:+$(basename "$last" | cut -c1-50)}${last:-(nothing yet)}" \
            3 "Open DraStic's own file browser" \
            4 "Save manager (old saves, pick a save file)" \
            5 "Options" \
            6 "Help" \
            7 "Exit to EmulationStation") || return
        case "$c" in
            1) play_loop ;;
            2) [ -n "$last" ] && play_loop "$last" ;;
            3) launch_browser ;;
            4) save_manager ;;
            5) options_menu ;;
            6) msg "$(cat "$DP/HELP.txt" 2>/dev/null || echo 'See README in the drastic-plus folder.')" 28 78 ;;
            *) return ;;
        esac
    done
}

# --------------------------------------------------------------------------

# allow "source" for tests without starting the menu
[ "${BASH_SOURCE[0]}" != "$0" ] && return 0

if [ "$1" = "--play" ] && [ -n "$2" ]; then
    # direct launch (e.g. from a custom ES system): drastic-plus.sh --play /roms/nds/game.nds
    setup_data_dir || exit 1
    ui_start
    launch_game "$2"
    ui_end
    exit 0
fi

setup_data_dir || { echo "Cannot create $DP"; exit 1; }
log "launcher start"
ui_start
main_menu
ui_end
exit 0
