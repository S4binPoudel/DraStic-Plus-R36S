# DraStic Plus (for R36S · ArkOS / dArkOS)

DraStic Plus is the DraStic 2.5.2.2 that is already on your device with extra features added. It shows up as a separate entry under **Ports** in EmulationStation.

The normal NDS → DraStic in EmulationStation keeps working exactly as before. DraStic Plus never changes `/opt/drastic` and never writes to the old saves. It keeps its own config and saves, and only **copies** old saves in.

All stock DraStic features remain: its menu, controls, cheats, savestates, fake microphone button, touch cursor, screen swap and orientation keys.

## What's added

| Feature | Where | Default |
|---|---|---|
| **Mic sound**: Stock / Blow (noise) / Tone (hum) / WAV file | DraStic+ menu | Stock |
| **Mic loudness** slider, 5 % → 100 % (Low … Very high) | DraStic+ menu | 60 % |
| **Mic pitch** slider, 55 Hz → 3500 Hz (WAV: playback speed) | DraStic+ menu | 440 Hz |
| **Stylus speed** (right stick touch cursor) slider: Stock, 10 % → 400 % | DraStic+ menu | Stock |
| **Stick deadzone** slider, 0 – 50 % | DraStic+ menu | 15 % |
| **Stick response**: Linear / Precise | DraStic+ menu | Precise |
| **Touch hold button**: any button you pick toggles a held touch | DraStic+ menu | None |
| **Hide cursor on hold** | DraStic+ menu | On |
| **Edge re-grab**: endless drag while held (lift + touch again at the start point) | DraStic+ menu | On |
| **Re-grab gap** slider, 1 – 6 frames | DraStic+ menu | 2 frames |
| **Screen overlay**: main screen full size + the other screen small on top | DraStic+ menu, SELECT+X | Off |
| **Overlay size** slider, 20 – 100 % | DraStic+ menu, Move / resize | 35 % |
| **Overlay position**: Top right / Top left / Bottom right / Bottom left / Custom | DraStic+ menu, Move / resize | Top right |
| **Overlay opacity** slider, 0 – 100 % | DraStic+ menu, SELECT+L/R | 80 % |
| **Quit game** (DraStic saves and closes cleanly) | SELECT+START, DraStic+ menu | — |
| Performance hacks (see below) | DraStic+ menu / Options | all Off |
| Separate saves, old-save import, manual save picker | Launcher | on |

The mic preview in the menu shows the waveform for the current settings while you adjust them.

### Controls in game

- **SELECT + Y**: open the DraStic+ menu (the game pauses). Use the D-pad to move and change values, A to select, B to close.
- **SELECT + X**: screen overlay on/off.
- **SELECT + L / R**: overlay opacity −/+ 10 % (only while the overlay is on).
- **SELECT + START**: quit the game. DraStic runs its own quit, so saves are written, and you land back on the game list.
- **Touch hold button** (if you set one): press once to keep the screen touched, drag with the right stick, press again to let go. "TOUCH HOLD" shows in the corner while it's held.
- Everything else is your normal DraStic mapping. Hold your **Fake Microphone** button for the mic. If it isn't mapped yet, set it in DraStic's own menu → Controls.

These combos don't clash with the ArkOS hotkeys (FN + D-pad for brightness, volume keys, SELECT + FN for battery).

### Microphone

DraStic's own fake mic is quiet: it only reaches about 12 % of the DS microphone range. That's why some "blow into the mic" moments don't react. Set **Mic sound** to *Blow* and raise **Mic loudness** until the game responds.

- *Tone* is a buzzing, voice-like hum at the chosen pitch, for games that listen for a voice or a whistle.
- *WAV* plays DraStic's `microphone/microphone.wav` (or `<game name>.wav`) on a loop. It is scaled to your chosen loudness, and the pitch slider sets the playback speed.
- If you move a mic slider while the sound is on *Stock*, it switches to *Blow* so the slider takes effect.

### Stylus (right stick)

*Stock* keeps DraStic's own cursor: three fixed speeds and a ~30 % deadzone. Any other value gives smooth analog control. 100 % equals DraStic's top speed of 3 px per frame, and 400 % is four times faster. Movement is proportional to how far you push the stick. Slow speeds still work thanks to sub-pixel movement. The *Precise* response gives fine control near the center.

Your right-stick press (touch) still works as before.

**Touch hold**: in the DraStic+ menu, go to *Touch hold button*, press A, then press the button you want. Picking your right-stick click turns that button into a toggle. Any free button works; SELECT is reserved for the hotkeys. Left on that row removes it again. The button's own DraStic action is replaced by the toggle, so pick one you don't need in the game.

While the touch is held:

- **The pointer is hidden** (*Hide cursor on hold*), so you only see what the game does.
- **Edge re-grab** keeps a drag going forever. DraStic stops the pointer at the screen edge, which would end a camera turn or a scroll. So just before the pointer gets within 10 px of the edge (moving outwards), the touch is lifted, the pointer jumps back to where you started the hold, and the touch goes down again. To the game this is a quick "lift and touch again", which is what drag controls expect.
- **Re-grab gap** is how many frames the touch stays lifted: 2 by default, about 33 ms. Many 3D games only read the touch screen every other frame and would miss a 1-frame lift, making the camera snap back; 2 frames avoids that. If a game still jumps back, raise it to 3. If it ignores the re-grab altogether, it needs a longer gap too.
- Turn **Edge re-grab** off for games where you drag objects to the edge of the screen (drag and drop), since a re-grab would drop the object.
- Start the hold with the pointer where you want drags to restart from; the middle of the screen is a good spot for camera control.

### Screen overlay (picture-in-picture)

The screen you would normally see (DraStic's main screen) fills the display. The other screen is shown smaller on top of it, in the top-right corner by default.

- **Overlay size**, **Overlay position** and **Overlay opacity** are in the DraStic+ menu.
- **Move / resize overlay…** pauses on the current frame so you can place the small screen anywhere: D-pad moves it (hold to go faster), L/R change its size, X jumps to the next corner, A keeps it, B cancels.
- Your normal **Swap Screens** button decides which screen is big and which is small.
- The stylus cursor is drawn on whichever screen is the touch screen, including the small one.
- Changing DraStic's screen orientation turns the overlay off and gives you that layout back. All existing layouts and switches are unchanged; the overlay is an extra mode.

### Performance hacks (all Off = stock)

DraStic itself is closed source, so these are the safe switches available from outside the emulator:

- **Precise timing**: tighter sleep timing, for smoother frame pacing.
- **Audio buffer** (Large ×2 / Huge ×4): less crackling when a game runs slow, at the cost of a little audio delay. Applies on the next launch.
- **Speed preset**: sets DraStic's own speed options: auto frameskip up to 3, threaded 3D on, edge marking off, high-res 3D off, frame blending off. Your previous values are saved and restored exactly when you turn it off. Applies on the next launch.

CPU, GPU and RAM clocks are boosted the same way as the normal NDS launcher, because EmulationStation runs `perfmax` for Ports too.

## Install

1. Copy the contents of the `ports` folder from the zip into the `ports` folder on your games card (the `EASYROMS` partition on a PC, `/roms/ports` on the device):
   ```
   ports/DraStic Plus.sh
   ports/drastic-plus/      (libdrastic_plus.so, dp-keys.gptk, HELP.txt)
   ```
   If your games are on the second SD card, use `/roms2/ports`.
2. Restart EmulationStation, or use *Update gamelists*. **DraStic Plus** appears under Ports.

On first start, the port copies your current DraStic controls and settings from `/opt/drastic/config/drastic.cfg`, so everything feels the same.

## Saves

| | Location |
|---|---|
| DraStic Plus (this port) | `ports/drastic-plus/backup` (.dsv), `ports/drastic-plus/savestates` (.dss) |
| EmulationStation DraStic | `/roms/nds/backup`, `/roms/nds/savestates` (via `/opt/drastic`), read only here |

- **Automatic**: the first time you play a game in DraStic Plus, its old save and savestates are copied in. After that the two versions are independent. An existing DraStic Plus save is never overwritten. This can be switched off in Options.
- **Save manager**: choose a game, then:
  - pick any `.dsv` or `.sav` file from `/roms/nds`, `/roms2/nds` or `/opt/drastic` by hand,
  - re-copy the EmulationStation save,
  - copy savestates,
  - or restore an earlier DraStic Plus save.

  Before anything is replaced, the current save is kept as `<game>.dsv.bak-<date>`.
- After you quit a game, you come back to the game list with that game highlighted. Press B there for the main menu. In Options you can choose to go straight back to EmulationStation instead.
- DraStic's file browser (launcher option 3) also works. Before it opens, any missing old game saves are copied in.

## Uninstall

Delete `ports/DraStic Plus.sh` and the `ports/drastic-plus` folder. Nothing else was changed.

## Troubleshooting

- Logs are in `ports/drastic-plus/logs/` (`drastic_plus.log`, `drastic.log`, `launcher.log`).
- If the game list doesn't come back after quitting a game, set Options → *After quitting a game* to *back to EmulationStation* and send me `launcher.log`.
- If you see *"unsupported DraStic build, extras off"*, your `/opt/drastic/drastic` is not the 2.5.2.2 build (md5 `17550db727f3b59d36b57746ad1944be`). Games still run normally, just without the extras.
- To run once without any extras, launch with `DRASTIC_PLUS_DISABLE=1`.
- To reset only the extras, use Options → *Reset DraStic+ extra settings* (or delete `drastic-plus/drastic_plus.cfg`).

## How it works

`libdrastic_plus.so` is loaded with `LD_PRELOAD` in front of the unmodified `/opt/drastic/drastic`.

- On start it checks byte signatures in the binary. If anything differs, it stays completely passive.
- It wraps four SDL calls: `SDL_PollEvent`, `SDL_RenderCopy`, `SDL_RenderPresent` and `SDL_OpenAudio`.
- DraStic's screen textures are ARGB8888 with an alpha byte that isn't real transparency. The overlay therefore blends without reading that alpha: on GLES2 it darkens the area and then adds the colour-scaled screen; other renderers fall back to an alpha-free copy.
- SELECT+START sends DraStic its own Quit, the same as choosing Exit in DraStic's menu.
- It patches one code path in memory only: the branch of `spu_get_microphone_sample` that runs while the fake-mic button is held. In *Stock* mode that path reproduces DraStic's original behaviour exactly.
- The library needs only glibc 2.17 symbols, so it loads on ArkOS (glibc 2.30) and dArkOS (glibc 2.41).

## Building

```bash
sudo apt install gcc-aarch64-linux-gnu libsdl2-dev   # plus libsdl2-dev:arm64 headers for SDL_config
SDL_CFLAGS="-I/usr/include/SDL2 -I/usr/include/aarch64-linux-gnu" ./build.sh
```

Tests (run on any Linux PC):

```bash
gcc -O1 -std=gnu11 -I/usr/include/SDL2 -o test_dp tests/unit/test_dp.c -lSDL2 -ldl
SDL_VIDEODRIVER=dummy DRASTIC_PLUS_CFG=/tmp/dp.cfg DRASTIC_PLUS_LOG=/tmp/dp.log ./test_dp
bash tests/launcher/test_launcher.sh
```

The unit tests run the overlay on both the software renderer and a real GLES2 renderer; add `DP_TEST_GLES2=1` with `SDL_VIDEODRIVER=offscreen` (needs Mesa) for the second one.

The touch-hold tests replay DraStic's own per-frame cursor and touch handling around the hook, with a "game" that reads the drag every 1, 2 or 3 frames. They check that the drag never jumps backwards, the held pointer never reaches the edge, and every lift lasts exactly the gap.

`tests/rom` holds a tiny homebrew test ROM (original ARM code, no Nintendo data). It shows a pattern on one screen, solid blue on the other, and a live mic-level bar, which makes it handy for checking the overlay and mic loudness on the device.
